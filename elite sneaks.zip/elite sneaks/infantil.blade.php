@extends('LAYOUTS.main')
@section('título','Home')
@section('conteudo')
<main>
<div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div>
            <div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div><div class="produto">
                <img src="IMAGENS/pngwing.com (7).png" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div>
    </main>
    @endsection