@extends('LAYOUTS.main')
@section('título','Home')
@section('conteudo')

<section>
            <h2>Categoria Masculina</h2>
            <p>Os melhores tênis para homens modernos e estilosos.</p>
            <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0001.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div>
            <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0002.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0003.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0004.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0005.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0006.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0007.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0008.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0009.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0010.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0011.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0012.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0013.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0014.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0015.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0016.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0017.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0018.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div>
        </section>
        @endsection