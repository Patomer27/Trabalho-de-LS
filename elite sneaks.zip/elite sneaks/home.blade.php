@extends('LAYOUTS.main')
@section('título','Home')
@section('conteudo')
<section class="intro">
            <h2>Bem-vindo à nossa loja!</h2>
            <p>Encontre os melhores tênis para todas as ocasiões.</p>
        
        <section class="destaques">
            <h2>Mais vendidos</h2>
             <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0003.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0004.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0005.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
                <img src="IMAGENS/IMG-20250330-WA0006.jpg" alt="Tênis Modelo 1">
                <h3>Tênis Esportivo</h3>
                <p>R$ 299,99</p>
                <button>Comprar</button>
            </div> <div class="produto">
        </section>
    @endsection



    